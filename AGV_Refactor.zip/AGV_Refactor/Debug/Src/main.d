Src/main.o: ../Src/main.c ../Inc/pwm.h ../Inc/bluetoothCommand.h \
 ../Inc/initIR.h ../Inc/pidUpdate.h ../Inc/encoder.h ../Inc/sigueLinea.h \
 ../Inc/color.h ../Inc/relay.h ../Inc/stm32f051x8.h ../Inc/core_cm0.h \
 ../Inc/cmsis_version.h ../Inc/cmsis_compiler.h ../Inc/cmsis_gcc.h \
 ../Inc/system_stm32f0xx.h ../Inc/temperatura.h ../Inc/us.h
../Inc/pwm.h:
../Inc/bluetoothCommand.h:
../Inc/initIR.h:
../Inc/pidUpdate.h:
../Inc/encoder.h:
../Inc/sigueLinea.h:
../Inc/color.h:
../Inc/relay.h:
../Inc/stm32f051x8.h:
../Inc/core_cm0.h:
../Inc/cmsis_version.h:
../Inc/cmsis_compiler.h:
../Inc/cmsis_gcc.h:
../Inc/system_stm32f0xx.h:
../Inc/temperatura.h:
../Inc/us.h:
