################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/bluetoothCommand.c \
../Src/color.c \
../Src/encoder.c \
../Src/initIR.c \
../Src/main.c \
../Src/pidUpdate.c \
../Src/pwm.c \
../Src/relay.c \
../Src/sendInfo.c \
../Src/sigueLinea.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/temperatura.c \
../Src/us.c 

OBJS += \
./Src/bluetoothCommand.o \
./Src/color.o \
./Src/encoder.o \
./Src/initIR.o \
./Src/main.o \
./Src/pidUpdate.o \
./Src/pwm.o \
./Src/relay.o \
./Src/sendInfo.o \
./Src/sigueLinea.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/temperatura.o \
./Src/us.o 

C_DEPS += \
./Src/bluetoothCommand.d \
./Src/color.d \
./Src/encoder.d \
./Src/initIR.d \
./Src/main.d \
./Src/pidUpdate.d \
./Src/pwm.d \
./Src/relay.d \
./Src/sendInfo.d \
./Src/sigueLinea.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/temperatura.d \
./Src/us.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F0 -DSTM32F051R8Tx -c -I../Inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/bluetoothCommand.cyclo ./Src/bluetoothCommand.d ./Src/bluetoothCommand.o ./Src/bluetoothCommand.su ./Src/color.cyclo ./Src/color.d ./Src/color.o ./Src/color.su ./Src/encoder.cyclo ./Src/encoder.d ./Src/encoder.o ./Src/encoder.su ./Src/initIR.cyclo ./Src/initIR.d ./Src/initIR.o ./Src/initIR.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/pidUpdate.cyclo ./Src/pidUpdate.d ./Src/pidUpdate.o ./Src/pidUpdate.su ./Src/pwm.cyclo ./Src/pwm.d ./Src/pwm.o ./Src/pwm.su ./Src/relay.cyclo ./Src/relay.d ./Src/relay.o ./Src/relay.su ./Src/sendInfo.cyclo ./Src/sendInfo.d ./Src/sendInfo.o ./Src/sendInfo.su ./Src/sigueLinea.cyclo ./Src/sigueLinea.d ./Src/sigueLinea.o ./Src/sigueLinea.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su ./Src/temperatura.cyclo ./Src/temperatura.d ./Src/temperatura.o ./Src/temperatura.su ./Src/us.cyclo ./Src/us.d ./Src/us.o ./Src/us.su

.PHONY: clean-Src

