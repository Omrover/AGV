Inc/encoderCount.o: ../Inc/encoderCount.c
