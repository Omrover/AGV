#include "stm32f051x8.h"
#include <stdint.h>

float errorSignal=0;
int n0,n1,n2,n3,n4;
int cargado=0;

void configTimerSL(void) {
	RCC->APB1ENR |= RCC_APB1ENR_TIM6EN; // Habilitar el reloj para TIM6
	// Configurar el prescaler y el auto-reload para 1 ms
	TIM6->PSC = 7; // 8 MHz / (7 + 1) = 1 MHz → 1 us por cuenta
	TIM6->ARR = 10; // Cuenta hasta 1 us
	TIM6->CR1 = TIM_CR1_CEN; // Iniciar el temporizador
	TIM6->DIER |= (1<<0); //Habilita interrupción del timer
	NVIC->ISER[0] |= (1<<17); // Interrupt Set Enable Register in NVIC
}

uint32_t readQTR(uint8_t pin){ //pin = [3, 4, 5, 6, 7]
    uint32_t count = 0;

    GPIOB->MODER &= ~(3<<(2*pin)); //limpiar bits
    GPIOB->MODER |=  (1<<(2*pin)); //configurar como salida
    GPIOB->ODR |= (1<<pin); //poner HIGH

    if(cargado==1){//cargar capacitor
		cargado =0;
		GPIOB->MODER &= ~(3<<(2*pin)); //configurar como entrada

		while((GPIOB->IDR & (1<<pin)) && count<3000){ //contar hasta que baje a LOW o timeout
			count++;
		}
		return count;
    }
    return count;
}

float lecturaLinea(void){
    RCC->AHBENR |= RCC_AHBENR_GPIOBEN;

    uint32_t sensor0, sensor1, sensor2, sensor3, sensor4;

        //leer sensores: PB3, PB4, PB5, PB6, PB7
        sensor0 = readQTR(3);
        sensor1 = readQTR(4);
        sensor2 = readQTR(5);
        sensor3 = readQTR(6);
        sensor4 = readQTR(7);


        //definir "negro"
        n0 = (sensor0 > 2900);
        n1 = (sensor1 > 2900);
        n2 = (sensor2 > 2900);
        n3 = (sensor3 > 2900);
        n4 = (sensor4 > 2900);

        //si los 3 sensores de enmedio detectan negro...
        if (!n0){//Derecha 2
        	errorSignal=0.2;
        }if (!n1){//Derecha 1
        	errorSignal=0.1;
        }if (!n2){//Centro
        	errorSignal=0;
        }if (!n3){//Izquierda 1
        	errorSignal=-0.1;
        }if (!n4){//Izquierda 2
        	errorSignal=-0.2;
        }

        return errorSignal;
}

void TIM6_IRQHandler(void){//Delay de 10us
	TIM6->SR=0;//Reiniciar bandera de interrupción
	cargado=1;

}
