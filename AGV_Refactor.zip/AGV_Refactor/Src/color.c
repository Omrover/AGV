#include "stm32f051x8.h"
#include <stdint.h>

extern int flag3; // se activa cada 100ms por el Timer

volatile uint32_t pulse_count = 0;
int color = 0;
int bann =0;

uint32_t leer_frecuencia_EXTI(void) {
    if (flag3 == 1) {
        pulse_count = 0;
        flag3 = 0;

        // Esperar a que el timer vuelva a activar la flag
        while (flag3 == 0) {
            // mide durante 100 ms
        }
        //bann=0;
        return pulse_count;
    }
    return 0;
}

// === CONFIGURACIÓN DE EXTI PARA PB0 ===
void EXTI_Init(void) {
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGCOMPEN; // habilita SYSCFG
    RCC->AHBENR  |= RCC_AHBENR_GPIOBEN;       // habilita reloj de puerto B

    // PB0 como entrada
    GPIOB->MODER &= ~(0x3 << (0 * 2));        // modo entrada
    GPIOB->PUPDR &= ~(0x3 << (0 * 2));        // sin pull-up/pull-down
    // GPIOB->PUPDR |= (2 << (0 * 2)); // pull-down

    // Conectar PB0 -> EXTI0
    SYSCFG->EXTICR[0] &= ~SYSCFG_EXTICR1_EXTI0;
    SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI0_PB;

    // Configurar EXTI0: flanco de subida
    EXTI->IMR  |= EXTI_IMR_MR0;
    EXTI->RTSR |= EXTI_RTSR_TR0;
    EXTI->FTSR &= ~EXTI_FTSR_TR0;
    EXTI->PR   |= EXTI_PR_PR0; // limpiar bandera previa

    NVIC_SetPriority(EXTI0_1_IRQn, 2);
    NVIC_EnableIRQ(EXTI0_1_IRQn);
}

// Handler de interrupción para EXTI0–1
void EXTI0_1_IRQHandler(void) {
	if (EXTI->PR & EXTI_PR_PR0) {
	        pulse_count++;
	        bann = 1;
	        EXTI->PR |= EXTI_PR_PR0; // limpiar bandera
	    }
}

// === CONFIGURACIÓN DE PINES DEL SENSOR ===
void GPIOs_color(void) {
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN; // habilitar puerto A

	// PA4–PA7 → S0–S3 → salida push-pull
	GPIOA->MODER &= ~((0x3 << (4*2)) | (0x3 << (5*2)) | (0x3 << (6*2)) | (0x3 << (7*2)));
	GPIOA->MODER |=  ((1 << (4*2)) | (1 << (5*2)) | (1 << (6*2)) | (1 << (7*2)));
	GPIOA->OTYPER &= ~((1<<4)|(1<<5)|(1<<6)|(1<<7));
	GPIOA->PUPDR  &= ~((0x3 << (4*2)) | (0x3 << (5*2)) | (0x3 << (6*2)) | (0x3 << (7*2)));

	// Configurar sensor a escala de frecuencia del 20%
	// S0 = HIGH, S1 = LOW
	GPIOA->BSRR = (1 << 4); // S0 = 1
	GPIOA->BRR  = (1 << 5); // S1 = 0
}

uint32_t filtro_rojo(void) {
    // Activar filtro rojo (S2=0, S3=0)
    GPIOA->BRR = (1 << 6) | (1 << 7);
    return leer_frecuencia_EXTI();
}

uint32_t filtro_verde(void) {
    // Activar filtro verde (S2=1, S3=1)
    GPIOA->BSRR = (1 << 6) | (1 << 7);
    return leer_frecuencia_EXTI();
}

uint32_t filtro_azul(void) {
    // Activar filtro azul (S2=0, S3=1)
    GPIOA->BRR  = (1 << 6);
    GPIOA->BSRR = (1 << 7);
    return leer_frecuencia_EXTI();
}

int detectar_color(void) {
    uint32_t rojo, verde, azul;
    uint32_t valor_max;

    rojo  = filtro_rojo();
    verde = filtro_verde();
    azul  = filtro_azul();

    valor_max = rojo;
    if (verde > valor_max) valor_max = verde;
    if (azul > valor_max) valor_max = azul;

    if (valor_max < 50) {
        return 0; // valor muy bajo → sin color
    }

    if (rojo > verde && rojo > azul && rojo > (verde + azul) * 0.6f) {
        color = 1; // rojo
    } else if (verde > rojo && verde > azul && verde > (rojo + azul) * 0.6f) {
        color = 2; // verde
    } else if (azul > rojo && azul > verde && azul > (rojo + verde) * 0.6f) {
        color = 3; // azul
    } else {
        color = 0; // indefinido
    }

    return color;
}
