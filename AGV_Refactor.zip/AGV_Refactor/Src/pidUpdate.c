#include <string.h>
#include <stdint.h>
#include "encoder.h"
#include "pwm.h"

// Definición de estructuras para mayor modularidad
struct Velocity {
    float RefAngVel;
    float AngVel;
};

struct PID {
    const float dt;
    const float kp;
    const float ki;
    const float kd;
    float e;
    float e_1;
    float inte;
    float der;
    float m;
};

struct Encoder {
    int encCount;
    int encPrev;
    int delta;
};

struct Filter {
    float RPM;
    float RPM_f;
    float RPM_f_1;
};

// Variables globales inicializadas
struct Velocity RVel = {0, 0};
struct Velocity LVel = {0, 0};
struct PID RPID = {0.01f, 0.8f, 5.0f, 0.00001f, 0, 0, 0, 0, 0};
struct PID LPID = {0.01f, 0.8f, 5.0f, 0.00001f, 0, 0, 0, 0, 0};
struct Encoder encR = {0, 0, 0};
struct Encoder encL = {0, 0, 0};
struct Filter RF = {0, 0, 0};
struct Filter LF = {0, 0, 0};

// Constantes para el filtro (debes ajustarlas)
const float a = 0.6321f;  // Coeficiente filtro
const float b = -0.3679f;
void pidUpdate(float WR,float WL) {
        // Código para rueda derecha
        encR.encCount = getEncoderCountR();
        encR.delta = (int16_t)(encR.encCount - encR.encPrev);
        encR.encPrev = encR.encCount;

        RVel.AngVel = ((encR.delta / 2000.0f) * (60.0f / RPID.dt));

        // Filtro
        RF.RPM = RVel.AngVel;
        RF.RPM_f = a * RF.RPM - b * RF.RPM_f_1;
        RF.RPM_f_1 = RF.RPM_f;

        RVel.RefAngVel = WR;  // Referencia

        RPID.e = RVel.RefAngVel - RF.RPM_f;
        RPID.inte = RPID.inte + RPID.dt * RPID.e;

        RPID.der = (RPID.e - RPID.e_1) / RPID.dt;
        RPID.m = RPID.kp * RPID.e + RPID.ki * RPID.inte + RPID.kd * RPID.der;
        RPID.e_1 = RPID.e;

        // limites de saturación
		if (RPID.m > 500.0f) RPID.m = 500.0f;
		if (RPID.m < -500.0f) RPID.m = -500.0f;

    	// Código para rueda izquierda
		encL.encCount = getEncoderCountL();
		encL.delta = (int16_t)(encL.encCount - encL.encPrev);
		encL.encPrev = encL.encCount;

		LVel.AngVel = ((encL.delta / 2000.0f) * (60.0f / LPID.dt));

		// Filtro
		LF.RPM = LVel.AngVel;
		LF.RPM_f = a * LF.RPM - b * LF.RPM_f_1;
		LF.RPM_f_1 = LF.RPM_f;

		LVel.RefAngVel = WL;  // Referencia

		LPID.e = LVel.RefAngVel - LF.RPM_f;
		LPID.inte = LPID.inte + LPID.dt * LPID.e;
		LPID.der = (LPID.e - LPID.e_1) / LPID.dt;
		LPID.m = LPID.kp * LPID.e + LPID.ki * LPID.inte + LPID.kd * LPID.der;
		LPID.e_1 = LPID.e;

		// limites de saturación
		if (LPID.m > 500.0f) LPID.m = 500.0f;
		if (LPID.m < -500.0f) LPID.m = -500.0f;

		setDuty(RPID.m,LPID.m);

}
