/*
 * bluetoothCommand.c
 *
 *  Created on: Sep 7, 2025
 *      Author: Ivani
 */
#include <stdio.h>
#include "bluetoothCommand.h"
#include "pwm.h"
#include "stm32f051x8.h"

void bluetoothInit(void){
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN;
	RCC->APB1ENR |= RCC_APB1ENR_USART2EN;//Habilitar Reloj para el periférico de comunicación USART

	// Configurar pines PA2 (TX) y PA3 (RX) como función alterna
	GPIOA->MODER |= (GPIO_MODER_MODER2_1 | GPIO_MODER_MODER3_1);
	GPIOA->AFR[0] &= ~((0xF << (2*4)) | (0xF << (3*4))); // limpiar
	GPIOA->AFR[0] |=  ((0x1 << (2*4)) | (0x1 << (3*4))); // poner AF1


	USART2->BRR = 8000000 / 9600;  // Baudrate a 9600 (8 MHz clock)
	USART2->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE | USART_CR1_RXNEIE;//Habilitar transmisor, receptor, USART y  la interrupción para recepción

	NVIC_SetPriority(USART2_IRQn, 2);//Definir prioridad de interrupción media
	NVIC_EnableIRQ(USART2_IRQn);//Habilitar rutina de interrupción
}

// Definir las variables declaradas externas
volatile char uart_buffer[128];//Buffer de 128 caracteres
volatile uint8_t uart_head = 0, uart_tail = 0;//indices del buffer, (storage y reading)
char cmd_buffer[32];//Buffer para el mensaje a procesar
uint8_t idx = 0;//Indice del buffer pequeño
int V,W;

void processCommand(const char* cmd, int* V,int* W) {//Función para procesar comando de acción
    int tempV, tempW;
    if(sscanf(cmd, "%d %d", &tempV, &tempW) == 2) {//Escanea del buffer los argumentos para el set duty
    	*V = tempV;      // Asigna valor mediante puntero
		*W = tempW; // Asigna valor mediante puntero
	    }
}

void processCommand(const char* cmd, int* V,int* W) {//Función para procesar comando de acción
    int tempV, tempW;
    if(sscanf(cmd, "%d %d", &tempV, &tempW) == 2) {//Escanea del buffer los argumentos para el set duty
    	*V = tempV;      // Asigna valor mediante puntero
		*W = tempW; // Asigna valor mediante puntero
	    }
}

void processCommand(const char* cmd, int* V,int* W) {//Función para procesar comando de acción
    int tempV, tempW;
    if(sscanf(cmd, "%d %d", &tempV, &tempW) == 2) {//Escanea del buffer los argumentos para el set duty
    	*V = tempV;      // Asigna valor mediante puntero
		*W = tempW; // Asigna valor mediante puntero
	    }
}

void USART2_IRQHandler(void) {//Algoritmo de buffer circular
    if(USART2->ISR & USART_ISR_RXNE) {//Verifica si se recibe un dato al activarse la flag de interrupción
    	if (USART2->ISR & (USART_ISR_ORE | USART_ISR_FE | USART_ISR_NE)) {
    	    USART2->ICR |= USART_ICR_ORECF | USART_ICR_FECF | USART_ICR_NCF; // limpia errores
    	}
        uart_buffer[uart_head] = USART2->RDR;//Almacena el último dato recibido en el buffer
        uart_head = (uart_head + 1) % 128;//Actualiza el indice y evita desbordamiento

    }
}

void readCommand(char* command){
	while(uart_head != uart_tail) {//Si tenemos datos nuevos
		char c = uart_buffer[uart_tail];//Leemos el dato almacenado en el buffer
		uart_tail = (uart_tail + 1) % 128;//Actualizamos posición

		if(c == '\r' || c == '\n') {//Se detecta salto de linea
			cmd_buffer[idx] = '\0';//Cierra la cadena para string válido
			if(command=="Modo"){
				processCommand(cmd_buffer,&V,&W);//Procesa el comando
			}
			else if(command=="Recetas"){
				processCommand(cmd_buffer,&V,&W);//Procesa el comando
			}
			else if(command==2){
				processCommand(cmd_buffer,&V,&W);//Procesa el comando
			}
			idx = 0;//Reinicia el indice
		}
		else if(idx < sizeof(cmd_buffer)-1) {//Evita overflow
			cmd_buffer[idx++] = c;//Guarda caracter en la posición y luego cambia posición
		}
	}
}
