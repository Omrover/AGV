/*
 * temperatura.c
 *
 *  Created on: Oct 22, 2025
 *      Author: Ivani
 */

#include "stm32f051x8.h"
#include <stdint.h>
#include "temperatura.h"
#include "sendInfo.h"
#include <string.h>
#include <stdlib.h>

// VARIABLES GLOBALES
volatile uint16_t Raw_ADC_Value = 0;   // Valor ADC (0 a 4095)
volatile int16_t  Temperatura_x10 = 0; // Temperatura en decimas de °C (25.3°C a 253)
volatile float    Temp_C = 0.0f;       // Temperatura en grados °C con un decimal
extern int flag4;
// FUNCIONES


void GPIO_Config(void){
    RCC->AHBENR |= RCC_AHBENR_GPIOBEN;       // Habilita GPIOB
    GPIOB->MODER |= (3u << (1*2));           // PB1 analogico
    GPIOB->PUPDR &= ~(3u << (1*2));
}

void ADC1_Config(void){
    RCC->APB2ENR |= RCC_APB2ENR_ADCEN;       // Habilita ADC1
    RCC->CR2 |= RCC_CR2_HSI14ON;             // Enciende el oscilador HSI14
    while(!(RCC->CR2 & RCC_CR2_HSI14RDY)) {}

    if (ADC1->CR & ADC_CR_ADEN){
        ADC1->CR |= ADC_CR_ADDIS;
        while(ADC1->CR & ADC_CR_ADEN){}
    }

    ADC1->CR |= ADC_CR_ADCAL;                // Calibrar ADC
    while(ADC1->CR & ADC_CR_ADCAL) {}

    ADC1->CFGR1 = 0;
    ADC1->SMPR  = 0x7;                       // Mayor tiempo de muestreo

    ADC1->CR |= ADC_CR_ADEN;                 // Habilita ADC
    while(!(ADC1->ISR & ADC_ISR_ADRDY)) {}
}

uint16_t ADC_Read_PB1(void){
    ADC1->CHSELR = ADC_CHSELR_CHSEL9;                // Canal 9 (PB1)
    ADC1->CR |= ADC_CR_ADSTART;              // Inicia conversión
    while(!(ADC1->ISR & ADC_ISR_EOC)) {}
    return (uint16_t)ADC1->DR;               // Retorna valor ADC
}

// PROGRAMA PRINCIPAL
void lecturaTemp(void){
    GPIO_Config();
    ADC1_Config();

    if(flag4){
    	flag4=0;
        Raw_ADC_Value = ADC_Read_PB1();

        // Convertir a mV: (ADC / 4095) * 3000 mV
        int32_t mv = ((int32_t)Raw_ADC_Value * 3000 + 2047) / 4095;

        // LM35 10 mV por °C a 1°C = 10 mV a 1 décima °C = 1 mV
        Temperatura_x10 = mv;         // °C ×10
        Temp_C = mv / 10.0f;          // °C con decimal
        char temp[32];
        snprintf(temp, sizeof(temp), "Vel: %.2f mm/s\r\n", Temp_C);
        sendInfo(temp);
    }
}
