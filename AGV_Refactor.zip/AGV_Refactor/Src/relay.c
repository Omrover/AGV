/*
 * relay.c
 *
 *  Created on: Oct 22, 2025
 *      Author: Ivani
 */


#include "relay.h"

static void delay_ms(uint32_t ms){
    for(uint32_t i = 0; i < ms; ++i){
        for(volatile uint32_t j = 0; j < 8000; ++j){ __NOP(); }
    }
}

void paro(void){
    RCC->AHBENR |= RCC_AHBENR_GPIOCEN; // habilitar reloj de GPIOC

    	PARO_PORT->MODER  &= ~(3U << (PARO_PIN * 2));   //
        PARO_PORT->PUPDR  &= ~(3U << (PARO_PIN * 2));
        PARO_PORT->PUPDR  |=  (1U << (PARO_PIN * 2));   //pull-up interno


    // PA2 y PA3 como salida push-pull
    REL_PORT->MODER  &= ~((3U<<(REL_A_PIN*2)) | (3U<<(REL_B_PIN*2)));
    REL_PORT->MODER  |=  ((1U<<(REL_A_PIN*2)) | (1U<<(REL_B_PIN*2)));
    REL_PORT->OTYPER &= ~((1U<<REL_A_PIN) | (1U<<REL_B_PIN));
    REL_PORT->PUPDR  &= ~((3U<<(REL_A_PIN*2)) | (3U<<(REL_B_PIN*2)));


    // estado inicial: relés inactivos
    A_OFF(); B_OFF();

    uint8_t last = 1;  // 1 = suelto (alto)
    for(;;){
        uint8_t raw = ( (PARO_PORT->IDR & (1U<<PARO_PIN)) ? 1 : 0 );
        if(raw != last){
            delay_ms(20); // debounce
            raw = ( (PARO_PORT->IDR & (1U<<PARO_PIN)) ? 1 : 0 );
            if(raw != last){
                last = raw;
                if(last == 0){
                    // botón presionado - activar relés - motores apagados
                    A_ON(); B_ON();
                }else{
                    // botón suelto - desactivar relés - motores encendidos
                    A_OFF(); B_OFF();
                }
            }
        }

        __NOP();
    }
}
