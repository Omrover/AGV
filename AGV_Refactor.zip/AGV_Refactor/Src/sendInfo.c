/*
 * sendInfo.c
 *
 *  Created on: Sep 11, 2025
 *      Author: Ivani
 */

#include "stm32f051x8.h"
#include "sendInfo.h"

void sendInfo(char *str) {
    while(*str) {
        while(!(USART2->ISR & USART_ISR_TXE)); // Espera a que el registro esté vacío
        USART2->TDR = *str++;                  // Envía el carácter y avanza
    }
    while(!(USART2->ISR & USART_ISR_TC)); // Espera a que termine la transmisión
}

