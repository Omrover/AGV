/*
 * us.c
 *
 *  Created on: Oct 22, 2025
 *      Author: Ivani
 */


#include "stm32f051x8.h"
#include <stdint.h>

/* ============================
 * Variables para Live Expressions
 * ============================ */
volatile uint32_t EchoPulse_us = 0;      // Duración del pulso ECHO en microsegundos
volatile int32_t  Distance_cm_x10 = -1;  // Distancia en décimas de cm (253 => 25.3 cm)
volatile uint16_t LastCCR1 = 0;          // Lectura cruda de captura (debug)
volatile uint8_t  MeasureState = 0;      // 0: esperando subida, 1: esperando bajada, 2: terminado
volatile uint8_t  NoEchoTimeout = 0;     // 1 si hubo timeout sin eco
volatile uint8_t time=0;
volatile uint8_t time2=0;
volatile uint8_t time3=0;
volatile uint8_t time4=0;
volatile uint8_t time5=0;
volatile uint8_t fl=0;
volatile uint8_t fl2=0;
volatile uint8_t fl3=0;
volatile uint8_t fl4=0;
volatile uint8_t fl5=0;
/* ============================
 * Retardos sencillos (HSI ~8 MHz)
 * ============================ */
void timerMuestreoConfig(void){
	RCC->APB2ENR|= RCC_APB2ENR_TIM17EN; // Habilitar TIM17 Clock
	TIM17->PSC = 8-1; // 8MHz -> 1MHz
	TIM17->ARR = (1); // Set Autoreload value to 1000 us to wait
	TIM17->CR1 |= TIM_CR1_CEN; // Enable TIM16
	TIM17->DIER |= (1<<0); // Update Interrupt enable
	NVIC->ISER[0] |= (1<<22); // Interrupt Set Enable Register in NVIC
		//Nested vectored interrupt controller
}

void TIM17_IRQHandler(void){
	TIM17->SR = 0; // Clear status register
	time += 1;
	time2 += 1;
	time3 += 1;
	time4 += 1;
	time5 += 1;
	if(time==10000){
		fl = 1;
		time=0;
	}
	if(time2==30000){
		fl2=1;
		time2=0;
	}
	if(time3==80000){
		fl3=1;
		time3=0;
		}
	if(time4==2){
		fl4=1;
		time4=0;
			}
	if(time5==10){
		fl4=1;
		time5=0;
				}



}

/* ============================
 * GPIO:
 *   PC0 = TRIG (salida)
 *   PB8 = ECHO (AF2 -> TIM16_CH1)
 * ============================ */
void GPIO_BC(void){
    /* Clocks GPIOB y GPIOC */
    RCC->AHBENR |= RCC_AHBENR_GPIOBEN | RCC_AHBENR_GPIOCEN;

    /* PC0 como salida push-pull (TRIG) */
    GPIOC->MODER   &= ~(3u << (0*2));
    GPIOC->MODER   |=  (1u << (0*2));     // 01 = salida
    GPIOC->OTYPER  &= ~(1u << 0);         // push-pull
    GPIOC->OSPEEDR |=  (3u << (0*2));     // alta velocidad (opcional)
    GPIOC->PUPDR   &= ~(3u << (0*2));     // sin pull

    /* PB8 como AF2 (TIM16_CH1) */
    GPIOB->MODER   &= ~(3u << (8*2));
    GPIOB->MODER   |=  (2u << (8*2));     // 10 = alternate function
    GPIOB->PUPDR   &= ~(3u << (8*2));     // sin pull (o pull-down suave externo si hay ruido)
    /* AFR[1], pin 8 => bits [3:0] = 0b0010 (AF2) */
    GPIOB->AFR[1]  &= ~(0xFu << ((8-8)*4));
    GPIOB->AFR[1]  |=  (0x2u << ((8-8)*4));
}

/* ============================
 * TIM16: 1 MHz + captura en CH1 (PB8)
 * ============================ */
void TIM16_InputCapture_Config(void){
    RCC->APB2ENR |= RCC_APB2ENR_TIM16EN;

    TIM16->PSC = 8 - 1;     // 8 MHz / 8 = 1 MHz -> 1 tick = 1 us
    TIM16->ARR = 0xFFFF;    // 16 bits (~65 ms de ventana)

    /* CH1 como entrada mapeada a TI1 */
    TIM16->CCMR1 &= ~(3u << 0);  // CC1S
    TIM16->CCMR1 |=  (1u << 0);  // CC1S = 01 -> TI1

    /* Filtro de entrada: IC1F = 0011 (N=8) para antirruido moderado */
    TIM16->CCMR1 &= ~(0xFu << 4);
    TIM16->CCMR1 |=  (3u   << 4);

    /* Captura inicialmente en flanco de subida (CC1P=0) */
    TIM16->CCER &= ~TIM_CCER_CC1P;

    /* Habilitar captura CH1 */
    TIM16->CCER |= TIM_CCER_CC1E;

    /* Limpiar banderas y habilitar interrupción de captura */
    TIM16->SR   = 0;
    TIM16->DIER |= TIM_DIER_CC1IE;

    /* Arrancar contador */
    TIM16->CR1 |= TIM_CR1_CEN;

    /* NVIC */
    NVIC_EnableIRQ(TIM16_IRQn);
    NVIC_SetPriority(TIM16_IRQn, 1);
}

/* ============================
 * Pulso TRIG ~10 us (PC0)
 * ============================ */
void HCSR04_Trigger(void){
    /* Asegura bajo */
    GPIOC->BSRR = (uint32_t)(1u << (0 + 16)); // reset PC0
    /* Pulso alto 10 us */
    if(fl4==1){
    	fl4=0;
    GPIOC->BSRR = (1u << 0);   }               // set PC0
    if(fl5==1){
    	fl5=0;
    GPIOC->BSRR = (uint32_t)(1u << (0 + 16));} // reset PC0}
}

/* ============================
 * Medición blocking con timeout
 * ============================ */
uint8_t HCSR04_MeasureOnce(void){
    NoEchoTimeout = 0;
    MeasureState  = 0;  // esperando flanco de subida

    /* Polaridad a flanco de subida */
    TIM16->CCER &= ~TIM_CCER_CC1P;

    /* Disparar TRIG */
    HCSR04_Trigger();

    /* Esperar subida (hasta ~10 ms) */
    if (fl==1){
    	fl=0;
		if (MeasureState == 0){
			NoEchoTimeout   = 1;
			EchoPulse_us    = 0;
			Distance_cm_x10 = -1;
			return 0;
		}
    }

    /* Esperar bajada (hasta ~30 ms) */
   if (fl==2){
	   fl=0;
    if (MeasureState == 1){
        NoEchoTimeout   = 1;
        EchoPulse_us    = 0;
        Distance_cm_x10 = -1;
        /* Reponer a subida para el siguiente ciclo */
        TIM16->CCER &= ~TIM_CCER_CC1P;
        return 0;
    }
   }


    /* Convertir a cm (x10 para décimas) -> cm ≈ us / 58 */
    if (EchoPulse_us > 0){
        Distance_cm_x10 = (int32_t)((EchoPulse_us * 10u + 29u) / 58u); // redondeo
    } else {
        Distance_cm_x10 = -1;
    }
    return 1;
}

/* ============================
 * ISR TIM16: captura CH1
 * ============================ */
void TIM16_IRQHandler(void){
    if (TIM16->SR & TIM_SR_CC1IF){
        uint16_t ccr = (uint16_t)TIM16->CCR1; // 16 bits
        LastCCR1 = ccr;

        if (MeasureState == 0){
            /* Flanco de subida: iniciar medición */
            TIM16->CNT  = 0;               // medir desde aquí
            TIM16->CCER |= TIM_CCER_CC1P;  // cambiar a flanco de bajada
            MeasureState = 1;
        } else {
            /* Flanco de bajada: finalizar medición */
            EchoPulse_us = ccr;            // 1 tick = 1 us
            TIM16->CCER &= ~TIM_CCER_CC1P; // volver a subida
            MeasureState = 2;
        }

        TIM16->SR &= ~TIM_SR_CC1IF;        // limpiar bandera
    }

    if (TIM16->SR & TIM_SR_UIF){
        TIM16->SR &= ~TIM_SR_UIF;          // limpiar overflow si apareciera
    }
}

/* ============================
 * main
 * ============================ */
int medUS(void){
    GPIO_BC();
    TIM16_InputCapture_Config();

    if (fl==3){
    	fl=3;
        (void)HCSR04_MeasureOnce();
        /* Repite cada ~80 ms para no saturar el sensor */

    }
    return Distance_cm_x10;
}
