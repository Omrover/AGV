/*
 * initIR.c
 *
 *  Created on: Aug 19, 2025
 *      Author: Ivani
 */

#include "stm32f051x8.h"
#include "initIR.h"

int flag=0;int t=0;int t2=0;int flag2=0;int flag3=0;int flag4=0;

void initIR(){
// Inicializar TIM14
	RCC->APB1ENR|= RCC_APB1ENR_TIM14EN; // Habilitar TIM14 Clock
	TIM14->PSC = 8-1; // 8MHz -> 1MHz
	TIM14->ARR = (10000); // Set Autoreload value to 1000 us to wait
	TIM14->CR1 |= TIM_CR1_CEN; // Enable TIM14
	TIM14->DIER |= (1<<0); // Update Interrupt enable
	NVIC->ISER[0] |= (1<<19); // Interrupt Set Enable Register in NVIC
	//Nested vectored interrupt controller
}

void TIM14_IRQHandler(void){
	TIM14->SR = 0; // Clear status register
	t = t + 10;
	t2 += 10;
	flag = 1;
	if(t==100){
		flag2 = 1;
		flag3=1;
	}
	if(t2==10000){
		flag4=1;
		t2=0;
	}



}
