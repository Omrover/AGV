/*
 * 	encoder.c
 *  Created on: Sep 10, 2025
 *  Author: Ivani
 *  Description: Initialization and return of counts on the CNT register of the timer in
 *  			 encoder mode
 */
#include <encoder.h>
#include "stm32f051x8.h"


void encoderInit(void) {
    // Habilitar relojes
    RCC->AHBENR  |= RCC_AHBENR_GPIOAEN;   // Habilitar GPIOA
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;   // Habilitar TIM1
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;   // Habilitar TIM2


    // PA8 -> CH1
	GPIOA->MODER &= ~(3U << (8 * 2));
	GPIOA->MODER |=  (2U << (8 * 2));        // AF
	GPIOA->AFR[1] &= ~(0xF << ((8 - 8) * 4)); // AFR[1] para pines 8-15
	GPIOA->AFR[1] |=  (2U << ((8 - 8) * 4));   // AF2 = TIM1_CH1

	// PA9 -> CH2
	GPIOA->MODER &= ~(3U << (9 * 2));
	GPIOA->MODER |=  (2U << (9 * 2));        // AF
	GPIOA->AFR[1] &= ~(0xF << ((9 - 8) * 4)); // AFR[1] para pines 8-15
	GPIOA->AFR[1] |=  (2U << ((9 - 8) * 4));   // AF2 = TIM1_CH2

    // Configurar PA0 y PA1 como Alternate Function AF2 para timer 2
    // PA0 -> CH1
    GPIOA->MODER &= ~(3U << (0 * 2));
    GPIOA->MODER |=  (2U << (0 * 2));        // AF
    GPIOA->AFR[0] &= ~(0xF << (0 * 4));
    GPIOA->AFR[0] |=  (2U << (0 * 4));       // AF2 = TIM2_CH1

    // PA1 -> CH2
    GPIOA->MODER &= ~(3U << (1 * 2));
    GPIOA->MODER |=  (2U << (1 * 2));        // AF
    GPIOA->AFR[0] &= ~(0xF << (1 * 4));
    GPIOA->AFR[0] |=  (2U << (1 * 4));       // AF2 = TIM2_CH2

    // Configurar TIM1 en modo encoder
	TIM1->CR1   = 0x0000;  // Reset control register
	TIM1->SMCR  = 0x0000;  // Reset SMCR
	TIM1->CCMR1 = 0x0000;  // Reset CCMR1
	TIM1->CCER  = 0x0000;  // Reset CCER

    // Configurar TIM2 en modo encoder
    TIM2->CR1   = 0x0000;  // Reset control register
    TIM2->SMCR  = 0x0000;  // Reset SMCR
    TIM2->CCMR1 = 0x0000;  // Reset CCMR1
    TIM2->CCER  = 0x0000;  // Reset CCER

    // Mapear entradas a TI1/TI2
    TIM1->CCMR1 |= (1 << TIM_CCMR1_CC1S_Pos); // CC1 -> TI1
    TIM1->CCMR1 |= (1 << TIM_CCMR1_CC2S_Pos); // CC2 -> TI2
    TIM2->CCMR1 |= (1 << TIM_CCMR1_CC1S_Pos); // CC1 -> TI1
    TIM2->CCMR1 |= (1 << TIM_CCMR1_CC2S_Pos); // CC2 -> TI2

    // Polaridad normal
    TIM1->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);
    TIM2->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);

    // Encoder modo 3
    TIM1->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1; // SMS = 011
    TIM2->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1; // SMS = 011


    //Definir conteo pulsos timer 1
    TIM1->ARR = 0xFFFF;   // Rango máximo del contador (16 bits)
    TIM1->CNT = 0x0000;   // Reset del contador

    //Definir conteo pulsos timer 2
	TIM2->ARR = 0xFFFF;   // Rango máximo del contador (16 bits)
	TIM2->CNT = 0x0000;   // Reset del contador

    //Iniciar el timer 1
    TIM1->CR1 |= TIM_CR1_CEN;
    //Iniciar el timer 2
    TIM2->CR1 |= TIM_CR1_CEN;
}

int getEncoderCountR(void) {
    return (int)(TIM1->CNT);  // firmar a 16 bits para permitir valores negativos
}

int getEncoderCountL(void) {
    return (int)(TIM2->CNT);  // firmar a 16 bits para permitir valores negativos
}


