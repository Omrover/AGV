/*
 * temperatura.h
 *
 *  Created on: Oct 22, 2025
 *      Author: Ivani
 */

#ifndef TEMPERATURA_H_
#define TEMPERATURA_H_

void GPIO_Config(void);
void ADC1_Config(void);
uint16_t ADC_Read_PB1(void);
void lecturaTemp(void);
#endif /* TEMPERATURA_H_ */
