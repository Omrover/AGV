/*
 * pidUpdate.h
 *
 *  Created on: Sep 30, 2025
 *      Author: Ivani
 */

#ifndef PIDUPDATE_H_
#define PIDUPDATE_H_

void pidUpdate(float WR,float WL);

#endif /* PIDUPDATE_H_ */
