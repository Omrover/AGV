/*
 * pwmInit.h
 *
 *  Created on: Sep 7, 2025
 *      Author: Ivani
 */
#include <stdint.h>
#ifndef PWM_H_
#define PWM_H_
#define PWM_MAX_DUTY 100
void pwmInit(void);
void setDuty(int16_t pwmR, int16_t pwmL);

#endif /* PWM_H_ */
