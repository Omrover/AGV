/*
 * sendInfo.h
 *
 *  Created on: Sep 11, 2025
 *      Author: Ivani
 */

#ifndef SENDINFO_H_
#define SENDINFO_H_
#include <string.h>
#include <stdlib.h>

void sendInfo(char *str);

#endif /* SENDINFO_H_ */
