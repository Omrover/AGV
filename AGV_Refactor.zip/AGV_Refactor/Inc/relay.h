/*
 * relay.h
 *
 *  Created on: Oct 22, 2025
 *      Author: Ivani
 */

#ifndef RELAY_H_
#define RELAY_H_

#include "stm32f051x8.h"

#define PARO_PORT   GPIOC
#define PARO_PIN    1        // PC1 - paro de emergencia

#define REL_PORT   GPIOC
#define REL_A_PIN  2        // PC2 - IN1
#define REL_B_PIN  3        // PC3 - IN2

#define A_ON()   (REL_PORT->BRR  = (1U << REL_A_PIN))   // encender
#define A_OFF()  (REL_PORT->BSRR = (1U << REL_A_PIN))   // apagar
#define B_ON()   (REL_PORT->BRR  = (1U << REL_B_PIN))
#define B_OFF()  (REL_PORT->BSRR = (1U << REL_B_PIN))

void paro(void);

#endif /* RELAY_H_ */
