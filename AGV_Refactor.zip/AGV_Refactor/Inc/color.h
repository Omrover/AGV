/*
 * color.h
 *
 *  Created on: Oct 15, 2025
 *      Author: Ivani
 */

#ifndef COLOR_H_
#define COLOR_H_

uint32_t leer_frecuencia_EXTI(void);
void EXTI_Init(void);
void GPIOs_color(void);
uint32_t filtro_azul(void);
uint32_t filtro_verde(void);
uint32_t filtro_rojo(void);
int detectar_color(void);

#endif /* COLOR_H_ */
