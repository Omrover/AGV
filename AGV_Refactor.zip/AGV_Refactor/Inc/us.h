/*
 * us.h
 *
 *  Created on: Oct 22, 2025
 *      Author: Ivani
 */

#ifndef US_H_
#define US_H_

void timerMuestreoConfig(void);
void GPIO_BC(void);
void TIM16_InputCapture_Config(void);
void HCSR04_Trigger(void);
uint8_t HCSR04_MeasureOnce(void);
int medUS(void);
#endif /* US_H_ */
