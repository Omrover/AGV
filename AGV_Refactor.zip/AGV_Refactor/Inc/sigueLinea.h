/*
 * sigueLinea.h
 *
 *  Created on: Oct 15, 2025
 *      Author: Ivani
 */

#ifndef SIGUELINEA_H_
#define SIGUELINEA_H_

void configTimerSL(void);
uint32_t readQTR(uint8_t pin);
float lecturaLinea(void);

#endif /* SIGUELINEA_H_ */
