/*
 * encoderInit.h
 *
 *  Created on: Sep 10, 2025
 *      Author: Ivani
 */

#ifndef ENCODER_H_
#define ENCODER_H_

void encoderInit(void);
int getEncoderCountR(void);
int getEncoderCountL(void);


#endif /* ENCODER_H_ */
