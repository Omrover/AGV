/*
 * 	bluetoothCommand.h
 *
 *  Created on: Sep 7, 2025
 *      Author: Ivani
 */

#ifndef BLUETOOTHCOMMAND_H_
#define BLUETOOTHCOMMAND_H_

void bluetoothInit(void);
void processCommand(const char* cmd, int* V,int* W);
void readCommand(void);

#endif /* PROCESSCOMMAND_H_ */
